package com.example.navtest

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupWithNavController
import com.google.android.material.bottomnavigation.BottomNavigationView
import kotlinx.android.synthetic.main.home_fragment.*

class MainActivity : AppCompatActivity() {
    private lateinit var  navController: NavController
    private lateinit var onBackPressed: ListenerOnBackPressed


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        val navController = findNavController(R.id.nav_host)
        val appBarConfiguration = AppBarConfiguration(navController.graph)
        findViewById<Toolbar>(R.id.toolbar)
            .setupWithNavController(navController, appBarConfiguration)

        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)

       val bot_nav_controller = findNavController(R.id.nav_host)
       findViewById<BottomNavigationView>(R.id.bottomNavigationView).setupWithNavController(bot_nav_controller)


    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu,menu)
        return true
    }

    public fun setOnBackPressedListener(onBackPressed: ListenerOnBackPressed){
        this.onBackPressed = onBackPressed
        return
    }

    override fun onBackPressed() {


       return super.onBackPressed()
    }


    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item?.itemId


        when(id){
            android.R.id.home -> {
                onBackPressed()
                return true
            }
            android.R.id.list ->{

                onBackPressedDispatcher
            }
          R.id.jong ->{
              char_text.text="종종종"
          }
        }

        return super.onOptionsItemSelected(item)
    }
}
