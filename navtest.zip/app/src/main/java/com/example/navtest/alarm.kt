package com.example.navtest

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.alarm_fragment.*


class alarm : Fragment() {

    companion object {
        fun newInstance() = alarm()
    }

    private lateinit var viewModel: AlarmViewModel
    private var alarmMgr: AlarmManager?= null
    private lateinit var alarmIntent: PendingIntent

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        setHasOptionsMenu(true)
        return inflater.inflate(R.layout.alarm_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(AlarmViewModel::class.java)
        alarm_button.setOnClickListener {
            alarmMgr = context?.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmMgr?.set(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,SystemClock.elapsedRealtime()+60*1000
                ,alarmIntent
            )



        }
    }

}
