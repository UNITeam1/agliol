package com.example.navtest

import androidx.lifecycle.ViewModel

class CameraViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
