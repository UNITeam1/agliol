package com.example.navtest

public interface ListenerOnBackPressed {

    fun onBackPressed(): Boolean
}


