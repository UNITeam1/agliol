package com.example.navtest

import androidx.lifecycle.ViewModel

class ListViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
