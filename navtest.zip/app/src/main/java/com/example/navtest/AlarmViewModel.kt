package com.example.navtest

import androidx.lifecycle.ViewModel

class AlarmViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
