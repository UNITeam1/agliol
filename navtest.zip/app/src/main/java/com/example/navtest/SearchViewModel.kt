package com.example.navtest

import androidx.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
